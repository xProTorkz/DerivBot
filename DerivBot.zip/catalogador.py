import openai

openai.api_key = "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"
ASSISTANT_ID = "asst_k2ak7MNpC92Mm2LrsywTs0x5"


# === ENTRADA ===
def analisar_entrada_chatgpt(velas):
    try:
        # Cria thread
        thread = openai.beta.threads.create()

        # Envia as velas como input para o assistente
        openai.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=str(velas)
        )

        # Inicia a execução
        run = openai.beta.threads.runs.create(
            thread_id=thread.id,
            assistant_id=ASSISTANT_ID
        )

        # Aguarda a finalização
        while True:
            status = openai.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
            if status.status == "completed":
                break
            elif status.status == "failed":
                print("[⚠️ Assistant] Execução falhou (entrada).")
                return "AGUARDAR"

        # Coleta resposta
        mensagens = openai.beta.threads.messages.list(thread_id=thread.id)
        resposta = mensagens.data[0].content[0].text.value.strip().upper()

        print(f"[🔎 IA ENTRADA] Resposta: '{resposta}'")

        return resposta if resposta in ["CALL", "PUT"] else "AGUARDAR"

    except Exception as e:
        print(f"[ERRO GPT ENTRADA] {e}")
        return "AGUARDAR"


# === SAÍDA ===
def analisar_saida_chatgpt(velas):
    try:
        thread = openai.beta.threads.create()

        openai.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=str(velas)
        )

        run = openai.beta.threads.runs.create(
            thread_id=thread.id,
            assistant_id=ASSISTANT_ID
        )

        while True:
            status = openai.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
            if status.status == "completed":
                break
            elif status.status == "failed":
                print("[⚠️ Assistant] Execução falhou (saída).")
                return "SAIR"

        mensagens = openai.beta.threads.messages.list(thread_id=thread.id)
        resposta = mensagens.data[0].content[0].text.value.strip().upper()

        print(f"[🔎 IA SAÍDA] Resposta: '{resposta}'")

        return resposta if resposta in ["SAIR", "MANTER"] else "SAIR"

    except Exception as e:
        print(f"[ERRO GPT SAÍDA] {e}")
        return "SAIR"
