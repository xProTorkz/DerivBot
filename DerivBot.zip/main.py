import os
from flask import Flask, render_template, request, redirect, session
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "segredo_super_top_do_lucas")

LICENCAS_PATH = "licencas.json"

# === ROTA: ATIVAR CHAVE (AGORA ATIVA AUTOMATICAMENTE) ===
@app.route("/ativar")
def ativar_chave():
    chave = request.args.get("chave")

    if not chave:
        return "Chave de ativação não informada.", 400

    if not os.path.exists(LICENCAS_PATH):
        return "Banco de chaves não encontrado.", 500

    with open(LICENCAS_PATH, "r") as f:
        licencas = json.load(f)

    if chave not in licencas:
        return "Chave inválida ou inexistente.", 403

    licenca = licencas[chave]

    if licenca["usada"]:
        return f"❌ Essa chave já foi usada pela conta {licenca['deriv_account']} em {licenca['ativado_em']}.", 403

    # Salva chave e ativa automaticamente
    session["chave_ativacao"] = chave
    session["ativado_auto"] = True  # Flag de ativação automática

    # Marca como usada automaticamente
    licenca["usada"] = True
    licenca["deriv_account"] = "Vinculada"
    licenca["ativado_em"] = datetime.now().strftime("%Y-%m-%d %H:%M")

    with open(LICENCAS_PATH, "w") as f:
        json.dump(licencas, f, indent=2)

    return redirect("/configuracao")

# === ROTA RAIZ "/" ===
@app.route("/")
def home():
    if "token_deriv" in session:
        return redirect("/painel")
    return render_template("login.html")

# === LOGIN COM DERIV (formulário) ===
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        chave = request.args.get("chave")

        if not chave or not os.path.exists(LICENCAS_PATH):
            return "Chave não informada ou banco não encontrado.", 400

        with open(LICENCAS_PATH, "r") as f:
            licencas = json.load(f)

        if chave not in licencas:
            return "Chave inválida.", 403

        if licencas[chave]["usada"]:
            return f"Essa chave já foi usada por: {licencas[chave]['deriv_account']}", 403

        session["chave_ativacao"] = chave
        return redirect("/configuracao")

    return render_template("login.html")

# === CONFIGURAÇÃO DO TOKEN (agora só se veio da ativação automática) ===
@app.route("/configuracao", methods=["GET", "POST"])
def configuracao():
    if "token_deriv" in session:
        return redirect("/painel")

    # Bloqueia acesso se não tiver vindo da ativação automática
    if not session.get("ativado_auto"):
        return redirect("/")

    if request.method == "POST":
        token = request.form.get("token")
        aceite = request.form.get("aceite")

        if token and aceite:
            session["token_deriv"] = token
            return redirect("/painel")
        else:
            erro = "Você precisa colar o token e aceitar os termos para continuar."
            return render_template("configuracao.html", erro=erro)

    return render_template("configuracao.html")

# === PAINEL PROTEGIDO ===
@app.route("/painel")
def painel():
    if "token_deriv" not in session:
        return redirect("/login")

    # Confirma se a chave foi ativada
    chave = session.get("chave_ativacao")
    if not chave or not os.path.exists(LICENCAS_PATH):
        return redirect("/login")

    with open(LICENCAS_PATH, "r") as f:
        licencas = json.load(f)

    licenca = licencas.get(chave)

    if not licenca or not licenca["usada"]:
        return "❌ Acesso não autorizado. Ative sua chave primeiro.", 403

    return render_template("painel.html")

# === LOGOUT ===
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# === EXECUTAR APP ===
if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
